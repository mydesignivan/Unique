<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>

<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />

<title><?php wp_title('&laquo;', true, 'right'); ?> <?php bloginfo('name'); ?></title>

	<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/style.css" type="text/css" media="screen" />
	<?php if (get_option('rockwell_style')==''){?>
	<link rel="stylesheet" href="<?php bloginfo('template_directory'); ?>/css/pink.css" media="screen" />
	<?php }else{?>
	<link rel="stylesheet" href="<?php bloginfo('template_directory'); ?>/css/<?php echo get_option('rockwell_style'); ?>" media="screen" />
	<?php }?>
	<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/jquery.lightbox-0.5.css" media="screen" />
	 <link rel="stylesheet" href="<?php bloginfo('template_directory'); ?>/css/superfish.css" media="screen" />
	 
	 <!--[if gte IE 7]>
    <link rel="stylesheet" media="screen" type="text/css" href="<?php bloginfo('template_directory'); ?>/ie7.css" />
    <![endif]-->
	<script language="JavaScript" type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/jquery-1.3.2.min.js"></script>
	<script language="JavaScript" type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/jquery.form.js"></script>
	<script language="JavaScript" type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/jquery.lightbox-0.5.min.js">
	</script>
	<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/hoverintent.js"></script>
    <script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/superfish.js"></script>
	<!-- lightbox itialize script -->
	<script type="text/javascript">
		$(function() {
		   $('a.lightbox').lightBox();
		});
	 </script>
	<!-- ajax contact form -->
	 <script type="text/javascript">
		 $(document).ready(function(){
			  $('#contact').ajaxForm(function(data) {
				 if (data==1){
					 $('#success').fadeIn("slow");
					 $('#bademail').fadeOut("slow");
					 $('#badserver').fadeOut("slow");
					 $('#contact').resetForm();
					 }
				 else if (data==2){
						 $('#badserver').fadeIn("slow");
					  }
				 else if (data==3)
					{
					 $('#bademail').fadeIn("slow");
					}
					});
				 });
		</script>
		<script type="text/javascript"> 
			$(document).ready(function(){ 
				$("ul.sf-menu").superfish({
					autoArrows:  false,
					delay:       200,                             // one second delay on mouseout 
					animation:   {opacity:'show',height:'show'},  // fade-in and slide-down animation 
					speed:       'fast',                          // faster animation speed 
					autoArrows:  false,                           // disable generation of arrow mark-up 
					dropShadows: false                            // disable drop shadows 			
					}); 
			});
		</script>

	<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="<?php bloginfo('rss2_url'); ?>" />
	<link rel="alternate" type="text/xml" title="RSS .92" href="<?php bloginfo('rss_url'); ?>" />
	<link rel="alternate" type="application/atom+xml" title="Atom 1.0" href="<?php bloginfo('atom_url'); ?>" />

	<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
	<?php wp_get_archives('type=monthly&format=link'); ?>
	<?php //comments_popup_script(); // off by default ?>
	<?php wp_head(); ?>

</head>
<body>

<!-- begin wrapper -->
<div id="wrapper">
	<!-- begin header -->
	<div id="header">
	<div id="site5top"><a href="http://gk.site5.com/t/201">Site5 | Experts In Reseller Hosting.</a></div>
		<!-- begin top links -->
			
			<?php if ( function_exists( 'wp_nav_menu' ) ){
				wp_nav_menu( array( 'theme_location' => 'top-links', 'container_id' => 'topLinks', 'fallback_cb'=>'toplinks') );
				}else{
					toplinks();
				}?>
		<!-- end top links -->
		
		<!-- begin logo & tagline -->
		<div id="logoTag">
			<?php if(get_option('rockwell_logo_img')<>""){?>
			<div id="logoImg"><a href="<?php bloginfo('url'); ?>/"><img src="<?php echo get_option('rockwell_logo_img'); ?>" alt="<?php echo get_option('rockwell_logo_alt'); ?>" /></a>
			</div>
			<?php }else{?>
			<div id="logo">
				<h1><a href="<?php bloginfo('url'); ?>/"><?php echo get_option('rockwell_logo_txt'); ?></a></h1>
			</div>
			<?php }?>
			<?php if(get_option('rockwell_logo_tagline')!=""){?>
			<div id="tagline" style="width:<?php echo get_option('rockwell_tagline_width'); ?>px">
			<?php echo get_option('rockwell_logo_tagline'); ?> 
			</div>
			<?php }?>
		</div>
		<!-- end logo & tagline -->
		<!-- begin search box -->
			<form id="searchform" action="" method="get">
				<input id="s" type="text" name="s" value=""/>
				<input id="searchsubmit" type="submit" value=""/>
			</form>
		<!-- end search box -->
		<!-- begin top menu -->
		<?php if ( function_exists( 'wp_nav_menu' ) ){
				wp_nav_menu( array( 'theme_location' => 'main-menu', 'container_id' => 'topMenu', 'menu_class'=>'sf-menu', 'fallback_cb'=>'mainmenu') );
				}else{
					mainmenu();
				}?>
		<!-- end top menu -->
		<!-- begin social links -->
		<div id="socialLinks">
		<?php if(get_option('rockwell_twitter_link')!=""){ ?>
		<a href="<?php echo get_option('rockwell_twitter_link'); ?>" title="Twitter"><img src="<?php bloginfo('template_url'); ?>/images/ico_twitter.png" alt="Twitter" /></a><?php }?>
		<?php if(get_option('rockwell_facebook_link')!=""){ ?>
		<a href="<?php echo get_option('rockwell_facebook_link'); ?>" title="Facebook"><img src="<?php bloginfo('template_url'); ?>/images/ico_facebook.png" alt="Facebook" /></a><?php }?>
		<a href="<?php bloginfo('rss2_url'); ?>" title="RSS" ><img src="<?php bloginfo('template_url'); ?>/images/ico_rss.png" alt="RSS" /></a>
		
		</div>
		<!-- end social links -->
	</div>
	<!-- end header -->
	
	<!-- begin content -->
	<div id="content" class="clearfix">