	</div>
	<!-- end content -->

</div>
<!-- end wrapper -->

<!-- begin footer -->
	<div id="footer">
		&copy; 2009 Rockwell. All Right Reserved.
		<ul id="bottomLinks">
				<li><a href="<?php bloginfo('url'); ?>/">home</a></li>
				<?php wp_list_pages('title_li=') ?>
			</ul>
	</div>

<!-- end footer -->	
<?php if (get_option('rockwell_analytics') <> "") { 
		echo stripslashes(stripslashes(get_option('rockwell_analytics'))); 
	} ?>
<?php wp_footer(); ?>
</body>
</html>