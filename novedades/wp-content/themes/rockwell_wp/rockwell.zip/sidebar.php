<!-- begin box about -->
<?php if(get_option('rockwell_about_tit')!="" && get_option('rockwell_about_txt')!=""){?>
			<div id="boxAbout">
				<h2><?php echo get_option('rockwell_about_tit'); ?></h2>
				<p><?php echo get_option('rockwell_about_txt'); ?></p>
			</div>
		<?php }?>
			<!-- end box about -->
			<!-- begin colRightInner -->
			<div id="colRightInner">


<?php if(get_option('rockwell_ads')=='yes'){?>
<div id="ads" class="clearfix">
<?php do_action('ad-minister', array('position' => 'Sidebar', 'limit' => 6)); ?>	
<a href="<?php echo get_permalink(get_option('rockwell_advertise_page')); ?>">Find out more about advertising here! </a>
</div>	
<?php }?>

<?php 
	/* Widgetized sidebar */
	if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar() ) : ?>
							
<?php endif; ?>
<?php if(get_option('rockwell_flickr')=='yes'){?>
<div id="flickr">
<h2>PHOTOSTREAM</h2>
<?php get_flickrRSS(); ?> 
</div>
<?php }?>

			</div>
			<!-- end colRightInner -->
			<a href="http://gk.site5.com/t/202" id="site5_sidebar">Site5 | Experts In Reseller Hosting.</a>
		</div>
		<!-- end colRight -->
