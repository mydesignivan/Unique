<?php 

/*******************************
 WIDGETS AREAS
********************************/
if ( function_exists('register_sidebar') )
    register_sidebar(array(
        'before_widget' => '',
        'after_widget' => '',
        'before_title' => '<h2>',
        'after_title' => '</h2>',
    ));
	
/*******************************
 MENUS SUPPORT
********************************/
if ( function_exists( 'wp_nav_menu' ) ){
	if (function_exists('add_theme_support')) {
		add_theme_support('nav-menus');
		add_action( 'init', 'register_my_menus' );
		function register_my_menus() {
			register_nav_menus(
				array(
					'top-links' => __( 'Top Links' ),
					'main-menu' => __( 'Main Menu' ),
					'footer-links' => __( 'Footer Links' )
				)
			);
		}
	}
}

/* CallBack functions for menus in case of earlier than 3.0 Wordpress version or if no menu is set yet*/

function toplinks(){ ?>
		<div id="topLinks">
			<ul>
					<li><a href="<?php bloginfo('url'); ?>/">home</a></li>
					<?php wp_list_pages('title_li=') ?>
			</ul>
		</div>
<?php }

function footerlinks(){ ?>
		<div id="footerLinks">
			<ul>
					<li><a href="<?php bloginfo('url'); ?>/">home</a></li>
					<?php wp_list_pages('title_li=') ?>
			</ul>
		</div>
<?php }

function mainmenu(){ ?>
		<div id="topMenu">
			<ul class="sf-menu">
				<?php wp_list_categories('hide_empty=1&exclude=1&title_li='); ?>
			</ul>
		</div>
<?php }

/*******************************
 CONTENT TEXT LENGTH ADJUST
********************************/

function content($num) {  
		$theContent = get_the_content();  
		$output = preg_replace('/<img[^>]+./','', $theContent);  
		$limit = $num+1;  
		$content = explode(' ', $output, $limit);  
		array_pop($content);  
		$content = implode(" ",$content)."...";  
		echo $content;  
}

/*******************************
 POST IS IN DESCENDENT CATEGORY
********************************/

function post_is_in_descendant_category( $cats, $_post = null )
{
	foreach ( (array) $cats as $cat ) {
		// get_term_children() accepts integer ID only
		$descendants = get_term_children( (int) $cat, 'category');
		if ( $descendants && in_category( $descendants, $_post ) )
			return true;
	}
	return false;
}

/*******************************
 CUSTOM COMMENTS
********************************/
function mytheme_comment($comment, $args, $depth) {
   $GLOBALS['comment'] = $comment; ?>
   <li <?php comment_class(); ?> id="li-comment-<?php comment_ID() ?>">
  	

     <div id="comment-<?php comment_ID(); ?>">
      <div class="comment-author vcard">
	  <div class="comment-meta commentmetadata">
	   <?php echo get_avatar($comment,$size='32',$default='http://www.gravatar.com/avatar/61a58ec1c1fba116f8424035089b7c71?s=32&d=&r=G' ); ?>
	  <?php printf(__('%1$s at %2$s'), get_comment_date(),  get_comment_time()) ?> <br /><?php printf(__('<strong>%s</strong> says:'), get_comment_author_link()) ?><?php edit_comment_link(__('(Edit)'),'  ','') ?></div>
         
      </div>
      <?php if ($comment->comment_approved == '0') : ?>
         <em><?php _e('Your comment is awaiting moderation.') ?></em>
         <br />
      <?php endif; ?>

      <div class="text"><?php comment_text() ?></div>

      <div class="reply">
         <?php comment_reply_link(array_merge( $args, array('depth' => $depth, 'max_depth' => $args['max_depth']))) ?>
      </div>
     </div>
<?php }

/*******************************
  THEME OPTIONS PAGE
********************************/
add_action('admin_menu', 'rockwell_theme_page');

function rockwell_theme_page ()
{
	if ( count($_POST) > 0 && isset($_POST['rockwell_settings']) )
	{
		$options = array ( 'style','logo_img','logo_alt','logo_txt', 'logo_tagline', 'tagline_width', 'contact_email','ads', 'advertise_page', 'twitter_link', 'facebook_link', 'flickr', 'about_tit', 'about_txt', 'analytics');
		
		foreach ( $options as $opt )
		{
			delete_option ( 'rockwell_'.$opt, $_POST[$opt] );
			add_option ( 'rockwell_'.$opt, $_POST[$opt] );	
		}			
		
		 
	}
	add_theme_page(__('Rockwell Options'), __('Rockwell Options'), 'edit_themes', basename(__FILE__), 'rockwell_settings');	
}
function rockwell_settings ()
{?>
<div class="wrap">
	<h2>Rockwell Options Panel</h2>
	
<form method="post" action="">
	<table class="form-table">
		<!-- General settings -->
		<tr>
			<th colspan="2"><strong>General Settings</strong></th>
		</tr>
		<tr valign="top">
			<th scope="row"><label for="style">Theme Color Scheme</label></th>
			<td>
				<select name="style" id="style">
					<option value="pink.css" <?php if(get_option('rockwell_style') == 'pink.css'){?>selected="selected"<?php }?>>pink.css</option>
					<option value="blue.css" <?php if(get_option('rockwell_style') == 'blue.css'){?>selected="selected"<?php }?>>blue.css</option>
					<option value="orange.css" <?php if(get_option('rockwell_style') == 'orange.css'){?>selected="selected"<?php }?>>orange.css</option>
					
				</select> 
			</td>
		</tr>
		<tr valign="top">
			<th scope="row"><label for="logo_img">Logo image (full path to image)</label></th>
			<td>
				<input name="logo_img" type="text" id="logo_img" value="<?php echo get_option('rockwell_logo_img'); ?>" class="regular-text" />
			</td>
		</tr>
		<tr valign="top">
			<th scope="row"><label for="logo_alt">Logo image ALT text</label></th>
			<td>
				<input name="logo_alt" type="text" id="logo_alt" value="<?php echo get_option('rockwell_logo_alt'); ?>" class="regular-text" />
			</td>
		</tr>
		<tr valign="top">
			<th scope="row"><label for="logo_txt">Text logo</label></th>
			<td>
				<input name="logo_txt" type="text" id="logo_txt" value="<?php echo get_option('rockwell_logo_txt'); ?>" class="regular-text" />
				<br /><em>Leave this empty if you entered an image as logo</em>
			</td>
		</tr>
		<tr valign="top">
			<th scope="row"><label for="logo_tagline">Logo Tag Line</label></th>
			<td>
				<input name="logo_tagline" type="text" id="logo_tagline" value="<?php echo get_option('rockwell_logo_tagline'); ?>" class="regular-text" />
			</td>
		</tr>
		
		<tr valign="top">
			<th scope="row"><label for="tagline_width">Tag Line Box Width (px)</label><br /><em style="font-size:11px">Default width: 300px</em></th>
			<td>
				<input name="tagline_width" type="text" id="tagline_width" value="<?php echo get_option('rockwell_tagline_width'); ?>" class="regular-text" />
			</td>
		</tr>
		<tr valign="top">
			<th scope="row"><label for="contact_email">Email Address for Contact Form</label></th>
			<td>
				<input name="contact_email" type="text" id="contact_email" value="<?php echo get_option('rockwell_contact_email'); ?>" class="regular-text" />
			</td>
		</tr>
		
		<tr valign="top">
			<th scope="row"><label for="twitter_link">Twitter link</label></th>
			<td>
				<input name="twitter_link" type="text" id="twitter_link" value="<?php echo get_option('rockwell_twitter_link'); ?>" class="regular-text" />
			</td>
		</tr>
		<tr valign="top">
			<th scope="row"><label for="facebook_link">Facebook link</label></th>
			<td>
				<input name="facebook_link" type="text" id="facebook_link" value="<?php echo get_option('rockwell_facebook_link'); ?>" class="regular-text" />
			</td>
		</tr>
		<tr valign="top">
			<th scope="row"><label for="flickr">Flickr Photostream</label></th>
			<td>
				<select name="flickr" id="flickr">
					<option value="no" <?php if(get_option('rockwell_flickr') == 'no'){?>selected="selected"<?php }?>>No</option>
					<option value="yes" <?php if(get_option('rockwell_flickr') == 'yes'){?>selected="selected"<?php }?>>Yes</option>
				</select> 
				<br /><em>Make sure you have FlickrRSS plugin activated if you choose to enable Flickr Photostream</em>
			</td>
		</tr>
		<!-- Sidebar ABout Box-->
		<tr>
			<th colspan="2"><strong>Sidebar About Box</strong></th>
		</tr>
		<tr valign="top">
			<th scope="row"><label for="about_tit">Title</label></th>
			<td>
				<input name="about_tit" type="text" id="about_tit" value="<?php echo get_option('rockwell_about_tit'); ?>" class="regular-text" />
			</td>
		</tr>
		<tr valign="top">
			<th scope="row"><label for="about_txt">Text</label></th>
			<td>
				<textarea cols="60" rows="5" name="about_txt" type="text" id="about_txt" class="regular-text" /><?php echo get_option('rockwell_about_txt'); ?></textarea>
			</td>
		</tr>
		<!-- Ads Box Settings -->
		<tr>
			<th colspan="2"><strong>Ads Box Settings</strong></th>
		</tr>
		<tr>
			<th><label for="ads">Ads Section Enabled:</label></th>
			<td>
				<select name="ads" id="ads">
					<option value="no" <?php if(get_option('rockwell_ads') == 'no'){?>selected="selected"<?php }?>>No</option>
					<option value="yes" <?php if(get_option('rockwell_ads') == 'yes'){?>selected="selected"<?php }?>>Yes</option>
				</select> 
				<br /><em>Make sure you have AdMinister plugin activated and have the position "Sidebar" created within the plugin.</em>
			</td>
		</tr>
		<tr valign="top">
			<th scope="row"><label for="advertise_page">Advertise Page</label></th>
			<td>
				<?php wp_dropdown_pages("name=advertise_page&show_option_none=".__('- Select -')."&selected=" .get_option('rockwell_advertise_page')); ?>
			</td>
		</tr>
		
		<!-- Google Analytics -->
		<tr>
			<th><label for="ads">Google Analytics code:</label></th>
			<td>
				<textarea name="analytics" id="analytics" rows="7" cols="70" style="font-size:11px;"><?php echo stripslashes(get_option('rockwell_analytics')); ?></textarea>
			</td>
		</tr>
		
		
	</table>
	<p class="submit">
		<input type="submit" name="Submit" class="button-primary" value="Save Changes" />
		<input type="hidden" name="rockwell_settings" value="save" style="display:none;" />
	</p>
</form>

</div>
<?php }

/*******************************
  GET FIRST IMAGE IN POST
********************************/
function get_first_image() {
global $post, $posts;
$first_img = '';
ob_start();
ob_end_clean();
$output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
$first_img = $matches [1] [0];
if(empty($first_img)){ //Defines a default image
$first_img = "/images/default.jpg";
}
return $first_img;
} ?>